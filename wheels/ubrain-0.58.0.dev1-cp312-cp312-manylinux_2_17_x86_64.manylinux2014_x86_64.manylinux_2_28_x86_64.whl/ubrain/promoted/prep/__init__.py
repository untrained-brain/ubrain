"""Promoted law code (prep): copied unchanged from the research engine."""
