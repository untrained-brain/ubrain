"""Bodies: the client side of a body that runs in its own process.

A body (a simulated robot, a game) runs as a server in its own environment and
speaks the tick bridge's protocol over TCP. ubrain never imports a simulator; it
talks to the server:

    from ubrain.bodies import BodyClient, start_body
    proc, port = start_body(gallery=True, head_camera=True)    # the MuJoCo G1
    body = BodyClient("127.0.0.1", port)
    manifest = manifest_from_hello_03(body.hello)

`client.py` and `protocol.py` are copied byte for byte from the body package
(robot_mujoco/body; shipped in the ubrain repository as bodies/mujoco) and checked against BODIES.json;
they need only the standard library.
"""

from ubrain.bodies.client import BodyClient, decode_image
from ubrain.bodies.launch import find_body, free_port, kill_tree, start_body

__all__ = ["BodyClient", "decode_image", "start_body", "find_body", "free_port", "kill_tree"]
