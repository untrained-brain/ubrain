"""Promoted from brain_simulator/experiment/assoc (see ../PROMOTED.json)."""
