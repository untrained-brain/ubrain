"""Promoted from brain_simulator/experiment/ec (see ../PROMOTED.json)."""
