"""Promoted from brain_simulator/experiment/embody (see ../PROMOTED.json)."""
