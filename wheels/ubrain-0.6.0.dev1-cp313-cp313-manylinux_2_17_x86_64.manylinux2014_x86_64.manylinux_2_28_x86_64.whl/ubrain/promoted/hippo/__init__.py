"""Promoted from brain_simulator/experiment/hippo (see ../PROMOTED.json)."""
