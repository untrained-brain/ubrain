"""Promoted from brain_simulator/experiment/bg (see ../PROMOTED.json)."""
