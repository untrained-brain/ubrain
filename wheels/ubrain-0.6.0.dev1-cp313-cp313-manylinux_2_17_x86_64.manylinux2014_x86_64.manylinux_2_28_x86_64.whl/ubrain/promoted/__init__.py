"""Promoted regions: release artifacts copied from the lab by ubrain/promote.py.
Never edit them here; change the lab and promote again."""
