"""Promoted law code (spn): copied unchanged from the research engine."""
